Set WshShell = CreateObject("WScript.Shell")
' Bot klasörünün yolunu otomatik alır ve Node.js ile index.js dosyasını başlatır (0 = pencereyi tamamen gizler)
WshShell.Run "cmd.exe /c cd /d """ & CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName) & """ && node index.js", 1, False