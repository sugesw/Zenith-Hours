Set WshShell = CreateObject("WScript.Shell")
' Çalışan tüm Node.js işlemlerini sonlandırır (Steam botunu kapatır)
WshShell.Run "taskkill /f /im node.exe", 0, True